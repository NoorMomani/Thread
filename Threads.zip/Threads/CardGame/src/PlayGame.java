import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Random;

public class PlayGame {
    private final List<Player> players;
    private final Deck deck;
    private int numberForPlayers;
    private final Random randomCard;
    private boolean gameEnd = false;
    private int currentPlayerIndex = 0;

    public PlayGame(int numberForPlayers) {
        this.numberForPlayers = numberForPlayers;
        deck = new Deck();
        players = new ArrayList<>();
        randomCard = new Random();

        for (int i = 1; i <= numberForPlayers; i++) {
            players.add(new Player("Player " + i));
        }
    }

    public void drawCards() {
        int numCardsPerPlayer = deck.deckSize() / numberForPlayers;
        int remainingCards = deck.deckSize() % numberForPlayers;

        Iterator<Card> cardIterator = deck.iterator();

        for (Player player : players) {
            for (int j = 0; j < numCardsPerPlayer; j++) {
                Card card = cardIterator.next();
                player.getHand().add(card);
            }
        }

        for (int i = 0; i < remainingCards; i++) {
            Card card = cardIterator.next();
            players.get(i).getHand().add(card);
        }
    }

    private void deleteMatchingPairs(Player player) {
        List<Card> hand = player.getHand();
        List<Card> matchingPairs = new ArrayList<>();

        for (int i = 0; i < hand.size() - 1; i++) {
            Card currentCard = hand.get(i);
            for (int j = i + 1; j < hand.size(); j++) {
                Card otherCard = hand.get(j);
                if (isMatchingPair(currentCard, otherCard)) {
                    matchingPairs.add(currentCard);
                    matchingPairs.add(otherCard);
                    break;
                }
            }
        }
        hand.removeAll(matchingPairs);
    }

    private String getMatchingSuit(String suit) {

        switch (suit) {
            case "Spades":
                return "Clubs";
            case "Hearts":
                return "Diamonds";
            case "Diamonds":
                return "Hearts";
            case "Clubs":
                return "Spades";
            default:
                return null;
        }
    }

    public boolean isPlayerRound(int index) {
        return currentPlayerIndex == index;
    }

    public void removePlayerEmptyHand(Player player) {
        System.out.println(player.getName() + "'s hand is empty. Removing from the game.");
        players.remove(player);
        numberForPlayers--;
    }


    public void play() {

        drawCards();
        while (!gameEnd) {

            Player currentPlayer = players.get(currentPlayerIndex);
            Player nextPlayer = players.get((currentPlayerIndex + 1) % numberForPlayers);

            synchronized (this) {
                if (!nextPlayer.getHand().isEmpty()) {
                    int randomIndex = randomCard.nextInt(nextPlayer.getHand().size());
                    Card pickedCard = nextPlayer.getHand().remove(randomIndex);
                    currentPlayer.getHand().add(pickedCard);

                    deleteMatchingPairs(currentPlayer);

                    System.out.println(currentPlayer.getName() + " picked " + pickedCard);
                    if (currentPlayer.getHand().isEmpty()) {
                        removePlayerEmptyHand(currentPlayer);
                        currentPlayerIndex++;
                    }
                    if (nextPlayer.getHand().isEmpty()) {
                        removePlayerEmptyHand(nextPlayer);
                        if (currentPlayerIndex == players.size()) {
                            currentPlayerIndex--;
                        }
                    }
                }

                System.out.println("Player hands after " + currentPlayer.getName() + "'s turn:");
                for (Player player : players) {
                    System.out.println(player.getName() + ": " + player.getHand());
                    System.out.println(" ");
                }
                currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
                System.out.println();

                if (players.size() == 1) {
                    System.out.println(players.get(0).getName() + " has the Joker and loses!");
                    gameEnd = true;
                }
            }
        }
    }
    private boolean isMatchingPair(Card card1, Card card2) {
        if (card1.getRank().equals(card2.getRank())) {
            String[] suits = {"Spades", "Hearts", "Diamonds", "Clubs"};
            for (String suit : suits) {
                if (card1.getSuit().equals(suit) && card2.getSuit().equals(getMatchingSuit(suit))) {
                    return true;
                }
            }
        }
        return false;
    }
}
