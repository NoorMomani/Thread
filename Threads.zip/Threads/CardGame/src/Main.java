public class Main {
    public static void main(String[] args) {

        Thread []playerThread = new Thread[4];
        PlayGame game = new PlayGame(4);

        for(int i =0 ;i<4 ;i++ ){
            playerThread[i] = new Thread(new GameRound(game,i));
            playerThread[i].start();
        }

    }
}