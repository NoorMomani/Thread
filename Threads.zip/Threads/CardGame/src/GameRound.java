public class GameRound implements Runnable {

    private final PlayGame game;
    private final int index;

    public GameRound(PlayGame game, int index) {
        this.game = game;
        this.index = index;
    }

    @Override
    public void run() {
        synchronized (game) {
            while (game.isPlayerRound(index)) {
                try {
                    game.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            game.play();
            game.notifyAll();
        }
    }
}
